const form = document.getElementById("admission-form");
const status = document.getElementById("form-status");
const WHATSAPP_NUMBER = "923259815158";

// Add the familiar Pakistani CNIC separators while the student types.
const cnicInput = form.elements.cnic;
cnicInput.addEventListener("input", () => {
  const digits = cnicInput.value.replace(/\D/g, "").slice(0, 13);
  let formatted = digits;
  if (digits.length > 5) formatted = digits.slice(0, 5) + "-" + digits.slice(5);
  if (digits.length > 12) formatted = digits.slice(0, 5) + "-" + digits.slice(5, 12) + "-" + digits.slice(12);
  cnicInput.value = formatted;
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  status.textContent = "";

  if (!form.reportValidity()) return;

  const data = new FormData(form);
  const message = [
    "ANAS FOREX HUB — ADMISSION APPLICATION",
    "",
    `Student Name: ${data.get("studentName").trim()}`,
    `Father's Name: ${data.get("fatherName").trim()}`,
    `Date of Birth: ${data.get("dob")}`,
    `CNIC: ${data.get("cnic")}`,
    `Mobile / WhatsApp: ${data.get("mobile").trim()}`,
    `City: ${data.get("city").trim()}`
  ].join("\n");

  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, "_blank", "noopener,noreferrer");
});
