ANAS FOREX HUB — GitHub Pages Website

This is a static website package. It works on GitHub Pages without a server.

PUBLISH STEPS
1. Sign in at https://github.com/
2. Create a new repository (for example: anas-forex-hub).
3. Set repository visibility to Public if using the free GitHub Pages plan.
4. Upload the contents of this folder. Make sure index.html is in the repository root.
5. Open the repository Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait for the Pages URL to appear in Settings → Pages.

FORM BEHAVIOUR
- Required fields are validated in the browser.
- Date of birth uses a date picker.
- CNIC and Pakistani mobile number formats are validated.
- Submit opens WhatsApp chat with 0325-9816158 and fills in the application details.
- The student can review the message and press Send.
- Query WhatsApp contacts: 0325-9816158 and 0349-5354283.

IMPORTANT
This is a front-end form. It does not store applications in a database.
